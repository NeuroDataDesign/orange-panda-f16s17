from setuptools import setup

setup(
    name = 'py_discriminibility',
    version='0.1',
    scripts=['py_discriminibility']
)
