from setuptools import setup

setup(
    name = 'py_discriminibility',
    version='0.3',
    scripts=['disc']
)
