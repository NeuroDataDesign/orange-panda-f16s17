from setuptools import setup

setup(
    name = 'py_discriminibility',
    version='0.2',
    scripts=['py_discriminibility']
)
