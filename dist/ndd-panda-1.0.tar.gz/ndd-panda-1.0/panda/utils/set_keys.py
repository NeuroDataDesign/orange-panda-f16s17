import os
os.environ['AWS_ACCESS_KEY']=''
os.environ['AWS_SECRET_KEY']='' 
 

