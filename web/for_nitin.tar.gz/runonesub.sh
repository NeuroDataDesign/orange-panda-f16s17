# A function for generating memory and cpu summaries for fngs pipeline.
#
# Usage: ./runonesub.sh /path/to/rest /path/to/anat /path/to/output
# written by eric bridgeford

rm -rf $3
mkdir $3

pkill -f memlog
pkill -f cpulog
pkill -f disklog

./memlog.sh > ${3}/mem.txt &
memkey=$!
python cpulog.py ${3}/cpu.txt &
cpukey=$!
./disklog.sh $3 > ${3}/disk.txt &
diskkey=$!

atlas='/ndmg_atlases/atlases/atlas/MNI152_T1-2mm.nii.gz'
atlas_brain='/ndmg_atlases/atlases/atlas/MNI152_T1-2mm_brain.nii.gz'
atlas_mask='/ndmg_atlases/atlases/mask/MNI152_T1-2mm_brain_mask.nii.gz'
lv_mask='/ndmg_atlases/atlases/mask/HarvOx_lv_thr25-2mm.nii.gz'
label='/ndmg_atlases/atlases/label/princeton-visual-top-2mm.nii.gz /ndmg_atlases/atlases/label/desikan-2mm.nii.gz /ndmg_atlases/atlases/label/aal-2mm.nii.gz /ndmg_atlases/atlases/label/brodmann-2mm.nii.gz /ndmg_atlases/atlases/label/HarvardOxford-sub-maxprob-thr25-2mm.nii.gz /ndmg_atlases/atlases/label/HarvardOxford-cort-maxprob-thr25-2mm.nii.gz'

exec 4<$1
exec 5<$2

ndmg_func_pipeline $1 $2 $atlas $atlas_brain $atlas_mask $lv_mask $3 none $label --fmt graphml

sleep 30

kill $memkey $cpukey $diskkey
